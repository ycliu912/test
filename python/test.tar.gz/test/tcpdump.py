#!/usr/bin/python

import sys
import subprocess
import time
import os
import signal
from subprocess import call
import tempfile


y = 'y'
name = 'name'
stop = 'stop'


'''
tempfile = tempfile.mktemp()
file = open(tempfile,"w+b")
file.write(b"hello")
file.seek(0)
print(file.read())

try:
    os.remove(tempfile)
except OSError:
    pass
'''

def tcpdump(filename):
    process = subprocess.Popen(["tcpdump","-nN","-s","0","-i","any","-w","/tmp/" + filename + ".pcap"])
    os.system("echo %s >/tmp/tmptmp" % process.pid)
    return process

#filename = raw_input("What file would you to display?\n")
#print "package name:\n"

filename = sys.argv[1]

if(stop == filename):
    process_id_tmp = os.popen("cat /tmp/tmptmp")
    process_id = process_id_tmp.readlines()[0]
    os.system("kill -9 %s" % process_id)
    #os.kill(process_id,signal.SIGINT)
    print "finished!"
    os.system("rm -rf /tmp/tmptmp")
    #os.system("rm -rf /tmp/name.pcap")
else:
    process = tcpdump(filename)
    print "running time is 300s"
    time.sleep(300)
    process.kill()
#ans = input("stop it[y/n]:")
#print "stop it[y/n]:"
#ans = sys.stdin.readline()
#if(y == ans):
#    os.kill(process.pid,signal.SIGINT)
#    print "finished!"
#else:
#    exit() 
