#!/bin/bash
n=0
while :
do
  echo $n
  n=$[ $n + 1 ]
  sleep 2
done
