#!/bin/bash

/root/test/tcpdump.py $1 &
